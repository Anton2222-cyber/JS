const persons = [
  {
    "id": 1,
    "starQuantity": 5,
    "reviewDescribe": "В результате действий команды юристов удалось взыскать задолженость в размере 7 045 515 гривен.",
    "profilePicture":
      "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Dwayne_Johnson_2%2C_2013.jpg/800px-Dwayne_Johnson_2%2C_2013.jpg",
    "foolName": "Алексей.К.В",
    "company": "ООО “Энергон”"
  },
  {
    "id": 2,
    "starQuantity": 5,
    "reviewDescribe": "В результате действий команды юристов удалось взыскать задолженость в размере 10 123 643 гривен.",
    "profilePicture":
      "https://www.factroom.ru/wp-content/uploads/2019/06/10-faktov-o-evgenii-ponasenkove-kotoryj-svodit-vsekh-s-uma-1250x883.jpg",
    "foolName": "Yevgeny P.",
    "company": "ООО “Барон”"
  },
  {
    "id": 3,
    "starQuantity": 3,
    "reviewDescribe": "В результате действий команды юристов удалось взыскать задолженость в размере 5 123 643 гривен.",
    "profilePicture":
      "https://m.media-amazon.com/images/M/MV5BMTM3OTUwMDYwNl5BMl5BanBnXkFtZTcwNTUyNzc3Nw@@._V1_.jpg",
    "foolName": "Scarlett J.",
    "company": "ООО “Param”"
  },
  {
    "id": 4,
    "starQuantity": 4,
    "reviewDescribe": "В результате действий команды юристов удалось взыскать задолженость в размере 13 000 643 гривен.",
    "profilePicture":
      "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Jason_Statham_2018.jpg/375px-Jason_Statham_2018.jpg",
    "foolName": "Стейтем Д.",
    "company": "ООО “Paramer”"
  },
  {
    "id": 5,
    "starQuantity": 2,
    "reviewDescribe": "В результате действий команды юристов удалось взыскать задолженость в размере 2 000 643 гривен.",
    "profilePicture":
      "https://s-media-cache-ak0.pinimg.com/736x/ea/c3/5a/eac35aca219199dd9728114fbc8c8aa4.jpg",
    "foolName": "Loci L.",
    "company": "ООО “Асгард”"
  },
  {
    "id": 6,
    "starQuantity": 1,
    "reviewDescribe": "В результате действий команды юристов удалось взыскать задолженость в размере 16 000 643 гривен.",
    "profilePicture":
      "https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Leonardo_Dicaprio_Cannes_2019.jpg/330px-Leonardo_Dicaprio_Cannes_2019.jpg",
    "foolName": "Leonardo W.D.",
    "company": "ООО “Wolf”"
  }
]