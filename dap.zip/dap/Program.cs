﻿
using Dapper;
using Microsoft.Data.SqlClient;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.Metrics;


var connectionString = @"Data source=(localdb)\mssqllocaldb; Initial Catalog=DapperExample2;Integrated Security=True;";


//using (SqlConnection connection = new SqlConnection(connectionString))
//{
    //var customer = connection.Query<Customer>("select * from Customers").FirstOrDefault();

    //Console.WriteLine($"{customer.ID} {customer.Name} {customer.Email}");


    //var customerDto = connection.Query<CustomerDto>("select ID, Name from Customers").ToList();
    //for (int i = 0; i < customerDto.Count; i++)
    //{
    //    Console.WriteLine($"{customerDto[i].ID} {customerDto[i].Name}");
    //}
    WorkExample workExample = new WorkExample(@"Data source=(localdb)\mssqllocaldb; Initial Catalog=DapperExample2;Integrated Security=True;");

// workExample.PrintAll();
//workExample.PrintCustomerByCity("Cikiruh"); //Відображення усіх покупців з певного міста
//workExample.PrintCustomerByCountry("Indonesia");//Відображення усіх покупців з певної країни.
//workExample.PrintPromotionByCountry("Indonesia");//Відображення усіх акцій для певної країни
//workExample.PrintCountCustomersByCity();//Відобразити кількість покупців у кожному місті.
//workExample.PrintCountCustomersByCountry();//Відобразити кількість покупців у кожній країні
//workExample.PrintCountCityByCountry();//Відобразити кількість міст у кожній країні
//workExample.PrintAvgCityByCountry();//Відобразити середню кількість міст по всіх країнах
//workExample.PrintCustomerInterest();//Відобразити усі розділи, в яких зацікавлені певні покупці певної країни
//workExample.PrintProductPromByTimeAndInter("orci", new DateTime(2020, 10, 2), new DateTime(2023, 3, 21));//Відобразити усі акційні товари певного розділу за вказаний проміжок часу
//workExample.PrintPromProductByCustomerName("Andrea");//Відобразити усі акційні товари певного покупця
//workExample.PrintTop3CountryByCustomer();//Відобразити Топ-3 країни за кількістю покупців
//workExample.PrintTopCountryByCustomer();//Показати найкращу країну за кількістю покупців
//workExample.PrintTop3CityByCustomer();//Показати Топ-3 міст за кількістю покупців.
//workExample.PrintTopCityByCustomer();//Показати найкраще місто за кількістю покупців


//workExample.CreateCustomer(new Customer { Name="1", City="1", Country="1", Email="1", Birthdate= new DateTime(2004,10,10), Gender="1"});
//workExample.CreateInterest(new Interest { Name = "2" });
//workExample.CreatePromotionProduct(new PromotionProduct { InterestId = 1, PromotionId = 1, ProductName = "1" });
//workExample.UpdateCustomer(new Customer { ID = 21, Birthdate = new DateTime(2004, 10, 10), City = "123", Country = "123", Email = "123", Gender = "123", Name = "123" });
//workExample.UpdateInterest(new Interest { Name = "123", ID = 21 });
//workExample.UpdatePromotionProduct(new PromotionProduct { InterestId = 1, ProductName = "6", PromotionId = 6 });
//workExample.DeleteCustomer(21);
//workExample.DeleteInterest(21);
//workExample.DeletePromotionProduct(6, 1, "6");
//workExample.PrintCityByCountry("Indonesia"); //Відображення списку міст певної країни
//workExample.PrintInterestByCustomer("Leighton"); //Відображення списку розділів певного покупця
//workExample.PrintPromProductByInterest("hac");//Відображення списку акційних товарів певного розділу


//Customer customer = new Customer
//{

//    Name = "Joe"

//};
//var sqlQeryInsert = "insert into Customers (Name) values(@Name)";
//connection.Execute(sqlQeryInsert, customer);

//var sqlQeryInsert2 = "insert into Customers (Name) values(@Name); select cast(scope_identity() as int)";
//int? customerId = connection.Query<int>(sqlQeryInsert2,customer).FirstOrDefault();
//customer.ID=customerId.Value;

//var sqlQeryUpdate = "update Customers set Name=@Name where ID=@ID";
//connection.Execute(sqlQeryUpdate, customer);

//var sqlQeryDelete = "delete from Customers where ID=@ID";
//connection.Execute(sqlQeryDelete, customer);

//}
public interface IMailingListRepository
{
   
    void PrintAll();
    void PrintCustomerByCity(string city);
    void PrintCustomerByCountry(string country);

    void PrintPromotionByCountry(string country);

    void PrintCountCustomersByCity();
    void PrintCountCustomersByCountry();
    void PrintCountCityByCountry();
    void PrintAvgCityByCountry();
    void PrintCustomerInterest();
    void PrintProductPromByTimeAndInter(string interest, DateTime dataFrom, DateTime dataTo);
    void PrintPromProductByCustomerName(string name);

    void PrintTop3CountryByCustomer();

    void PrintTopCountryByCustomer();
    void PrintTop3CityByCustomer();
    void PrintTopCityByCustomer();
    void CreateCustomer(Customer customer);

    void CreateInterest(Interest interest);

    void CreatePromotionProduct(PromotionProduct product);
    //void Delete(int id);
    //Customer Get(int id);
    //List<Customer> GetCustomers();

    void UpdateCustomer(Customer customer);

    void UpdateInterest(Interest interest);

    void UpdatePromotionProduct(PromotionProduct product);

    void DeleteCustomer(int id);

    void DeleteInterest(int id);

    void DeletePromotionProduct( int PromotionId, int InterestId, string ProductName);

    void PrintCityByCountry(string country);
    void PrintInterestByCustomer(string customer_name);

    void PrintPromProductByInterest(string interest_name);
}
class WorkExample : IMailingListRepository
{
    string connectionString;
    public WorkExample(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public void CreateCustomer(Customer customer)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            var sqlQeryInsert2 = "insert into Customers (Name, Birthdate, Gender, Email, Country, City) values(@Name, @Birthdate, @Gender, @Email, @Country, @City); select cast(scope_identity() as int)";
            int? customerId = connection.Query<int>(sqlQeryInsert2, customer).FirstOrDefault();
            customer.ID = customerId.Value;


        }
    }

    public void CreateInterest(Interest interest)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            var sqlQeryInsert2 = "insert into Interests (Name) values(@Name); select cast(scope_identity() as int)";
            int? customerId = connection.Query<int>(sqlQeryInsert2, interest).FirstOrDefault();
            interest.ID = customerId.Value;


        }
    }

    public void CreatePromotionProduct(PromotionProduct product)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            var sqlQeryInsert2 = "insert into PromotionProducts (PromotionId, InterestId, ProductName) values(@PromotionId, @InterestId, @ProductName)";
            connection.Query<int>(sqlQeryInsert2, product);
            

        }
    }

    public void DeleteCustomer(int id)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Customer customer = new Customer
            {

                ID = id

            };
            var sqlQeryDelete = "delete from Customers where ID=@ID";
            connection.Execute(sqlQeryDelete, customer);
        }
    }

    public void DeleteInterest(int id)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Interest customer = new Interest
            {

                ID = id

            };
            var sqlQeryDelete = "delete from Interests where Id=@ID";
            connection.Execute(sqlQeryDelete, customer);
        }
    }

    public void DeletePromotionProduct(int PromotionId, int InterestId, string ProductName)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            PromotionProduct customer = new PromotionProduct
            {
                ProductName = ProductName,
                InterestId = InterestId,
                PromotionId = PromotionId
           
            };
            var sqlQeryDelete = "delete from PromotionProducts where ProductName=@ProductName and InterestId=@InterestId and PromotionId=@PromotionId";
            connection.Execute(sqlQeryDelete, customer);
        }
    }

    public void PrintAll()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            var customers = connection.Query<Customer>("select * from Customers").ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].Name} {customers[i].Email} {customers[i].Country} {customers[i].City}");
            }
            var interests = connection.Query<Interest>("select * from Interests").ToList();
            for (int i = 0; i < interests.Count; i++)
            {
                Console.WriteLine($"{interests[i].Name}");
            }
            var promotionProducts = connection.Query<PromotionProduct>("select * from PromotionProducts").ToList();
            for (int i = 0; i < promotionProducts.Count; i++)
            {
                Console.WriteLine($"{promotionProducts[i].ProductName}");
            }


        }
    }

    public void PrintAvgCityByCountry()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            var customers = connection.Query<Customer>("""
                select AVG(CountryAndCountCity.Count) as 'Count'
                from CountryAndCountCity
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].Count}");
            }
        }
    }

    public void PrintCityByCountry(string country)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Customer customer = new Customer
            {

                Country = country
            };
            var customers = connection.Query<Customer>("""
                select City from Customers
                where Country = @Country
                """, customer).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].City}");
            }
        }
    }

    public void PrintCountCityByCountry()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            var customers = connection.Query<Customer>("""
                select Country, COUNT(City) as 'Count'
                from Customers
                group by Country
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].Country} {customers[i].Count}");
            }
        }
    }

    public void PrintCountCustomersByCity()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            
            var customers = connection.Query<Customer>("""
                select City, COUNT(Name) as 'Count' 
                from Customers
                group by City
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].City} {customers[i].Count}");
            }
        }
    }

    public void PrintCountCustomersByCountry()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            var customers = connection.Query<Customer>("""
                select Country, COUNT(Name) as 'Count' 
                from Customers
                group by Country
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].Country} {customers[i].Count}");
            }
        }
    }

    public void PrintCustomerByCity(string city)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Customer customer = new Customer
            {

                City = city
            };
            var customers = connection.Query<Customer>("""
                select Name from Customers
                where City = @City
                """, customer).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].Name}");
            }
        }
    }

    public void PrintCustomerByCountry(string country)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Customer customer = new Customer
            {

                Country = country
            };
            var customers = connection.Query<Customer>("""
                select Name from Customers
                where Country = @Country
                """, customer).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].Name}");
            }
        }
    }

    public void PrintCustomerInterest()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            var customers = connection.Query<CustomerInterest>("""
                select Interests.Name as 'InterestName', Customers.Name as 'CustomerName'
                from CustomerInterests
                join Customers on Customers.ID = CustomerInterests.CustomerId
                join Interests on Interests.Id = CustomerInterests.InterestId
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].CustomerName} {customers[i].InterestName}");
            }
        }
    }

    public void PrintInterestByCustomer(string customer_name)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Customer customer = new Customer
            {

                Name = customer_name
            };
            var customers = connection.Query<CustomerInterest>("""
                select Interests.Name as 'InterestName'
                                from CustomerInterests
                                join Customers on Customers.ID = CustomerInterests.CustomerId
                                join Interests on Interests.Id = CustomerInterests.InterestId
                				where Customers.Name = @Name
                """, customer).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].InterestName}");
            }
        }
    }

    public void PrintProductPromByTimeAndInter(string interest, DateTime dataFrom, DateTime dataTo)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            ProductPromByTimeAndInter product = new ProductPromByTimeAndInter
            {

                Interest = interest,
                StartDate = dataFrom,
                EndDate = dataTo
            };
            var products = connection.Query<ProductPromByTimeAndInter>("""
                select ProductName
                from PromotionProducts
                join Interests on Interests.Id = PromotionProducts.InterestId
                join Promotions on Promotions.Id = PromotionProducts.PromotionId
                where Interests.Name = @Interest and Promotions.StartDate >= @StartDate AND Promotions.EndDate < @EndDate
                """, product).ToList();
            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine($"{products[i].ProductName}");
            }
        }
    }

    public void PrintPromotionByCountry(string country)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Promotion promotion = new Promotion
            {

                Country = country
            };
            var promotions = connection.Query<Customer>("""
                select Name from Promotions
                where Country = @Country
                """, promotion).ToList();
            for (int i = 0; i < promotions.Count; i++)
            {
                Console.WriteLine($"{promotions[i].Name}");
            }
        }
    }

    public void PrintPromProductByCustomerName(string name)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Customer customer = new Customer
            {

                Name = name
            };
            var products = connection.Query<ProductPromByTimeAndInter>("""
                select  ProductName
                from PromotionProducts
                join Interests on Interests.Id = PromotionProducts.InterestId
                join CustomerInterests on CustomerInterests.InterestId = Interests.Id
                join Customers on Customers.ID = CustomerInterests.CustomerId
                where Customers.Name = @Name
                """, customer).ToList();
            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine($"{products[i].ProductName}");
            }
        }
    }

    public void PrintPromProductByInterest(string interest_name)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            Interest interest = new Interest
            {

                Name = interest_name
            };
            var products = connection.Query<PromotionProduct>("""
                select ProductName
                from PromotionProducts
                join Interests on Interests.Id = PromotionProducts.InterestId
                where Interests.Name = @Name
                """, interest).ToList();
            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine($"{products[i].ProductName}");
            }
        }
    }

    public void PrintTop3CityByCustomer()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            var customers = connection.Query<Customer>("""
                select top(3) City
                from Customers 
                group by City
                order by count(Name) desc
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].City}");
            }
        }
    }

    public void PrintTop3CountryByCustomer()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            var customers = connection.Query<Customer>("""
                select top(3) Country
                from Customers 
                group by Country
                order by count(Name) desc
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].Country}");
            }
        }
    }

    public void PrintTopCityByCustomer()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            var customers = connection.Query<Customer>("""
                select top(1) City
                from Customers 
                group by City
                order by count(Name) desc
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].City}");
            }
        }
    }

    public void PrintTopCountryByCustomer()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {

            var customers = connection.Query<Customer>("""
                select top(1) Country
                from Customers 
                group by Country
                order by count(Name) desc
                """).ToList();
            for (int i = 0; i < customers.Count; i++)
            {
                Console.WriteLine($"{customers[i].Country}");
            }
        }
    }

    public void UpdateCustomer(Customer customer)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            var sqlQeryUpdate = """
                update Customers 
                set
                Name=@Name,
                Birthdate = @Birthdate,
                Gender = @Gender,
                Email = @Email,
                Country = @Country,
                City = @City
                where ID=@ID
                """;
            connection.Execute(sqlQeryUpdate, customer);


        }
    }

    public void UpdateInterest(Interest interest)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            var sqlQeryUpdate = """
                update Interests 
                set
                Name=@Name
                where Id=@ID
                """;
            connection.Execute(sqlQeryUpdate, interest);


        }
    }

    public void UpdatePromotionProduct(PromotionProduct product)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            var sqlQeryUpdate = """
                update PromotionProducts 
                set
                PromotionId=@PromotionId,
                ProductName=@ProductName
                where InterestId=@InterestId
                """;
            connection.Execute(sqlQeryUpdate, product);


        }
    }
}

[Table("Customers")]
public class Customer
{
    [Key]
    public  int ID { get; set; }

    public string Name { get; set; }

    public DateTime Birthdate { get; set; }

    public string Gender { get; set; }

    public string Email { get; set; }

    public string Country { get; set; }

    public string City { get; set; }

    public string Count { get; set; }
}

public class CustomerDto
{
    public int ID { get; set; }

    public string Name { get; set; }

}
public class Interest
{
    public int ID { get; set; }

    public string Name { get; set; }
}
public class CustomerInterest
{
    public string InterestName { get; set; }

    public string CustomerName { get; set; }
}
public class Promotion
{
    public int ID { get; set; }

    public string Name { get; set; }

    public string Country { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
}

public class PromotionProduct
{
    public int PromotionId { get; set; }
    public int InterestId { get; set; }

    public string ProductName { get; set; }
}
public class ProductPromByTimeAndInter
{
    public string ProductName { get; set; }

    public string Interest { get;set; }

    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
}
