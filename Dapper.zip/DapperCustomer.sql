﻿use DapperExample2
--CREATE TABLE Customers(ID int identity(1,1) primary key,					  
--					  Name nvarchar(50) NOT NULL,
--					  Birthdate datetime,
--					  Gender nvarchar(50),
--					  Email nvarchar(50) NOT NULL,
--					  Country nvarchar(50),
--					  City nvarchar(50))

--					  CREATE TABLE Promotions(Id int identity(1,1) primary key,
--					  Name nvarchar(50) NOT NULL,
--					  Country nvarchar(50),
--					  StartDate datetime NOT NULL,
--					  EndDate datetime NOT NULL)

--					  CREATE TABLE Interests(Id int identity(1,1) primary key,
--					  Name nvarchar(50) NOT NULL
--					  )

--					  CREATE TABLE CustomerInterests(
--					  CustomerId INT NOT NULL FOREIGN KEY REFERENCES Customers(ID) on delete cascade,
--					  InterestId INT NOT NULL FOREIGN KEY REFERENCES Interests(Id) on delete cascade)

--					  CREATE TABLE PromotionProducts(
--					  PromotionId INT NOT NULL FOREIGN KEY REFERENCES Promotions(Id) on delete cascade,
--					  InterestId INT NOT NULL FOREIGN KEY REFERENCES Interests(Id) on delete cascade,
--					  ProductName nvarchar(50))

					  --CREATE TABLE ArchivePromotionProducts(
					  --PromotionId INT NOT NULL FOREIGN KEY REFERENCES Promotions(Id) on delete cascade,
					  --InterestId INT NOT NULL FOREIGN KEY REFERENCES Interests(Id) on delete cascade,
					  --ProductName nvarchar(50))

--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Leighton', '2007-02-08', 'Male', 'lrainer0@linkedin.com', 'Indonesia', 'Cikiruh');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Murry', '2008-01-07', 'Male', 'mkittless1@drupal.org', 'China', 'Xitiangezhuang');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Elston', '2005-08-10', 'Male', 'ecamin2@sohu.com', 'Argentina', 'Tres Arroyos');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Andrea', '2008-04-18', 'Female', 'atatters3@taobao.com', 'Indonesia', 'Cireundang');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Reeva', '2005-08-19', 'Female', 'rphinn4@unblog.fr', 'Nigeria', 'Abuja');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Duncan', '2005-06-25', 'Male', 'dgater5@lulu.com', 'Brazil', 'Paranapanema');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Conrad', '2005-05-19', 'Male', 'cford6@cdbaby.com', 'Samoa', 'Falefa');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Sandra', '2007-11-16', 'Female', 'sspolton7@washington.edu', 'Russia', 'Donskoy');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Blithe', '2006-03-20', 'Female', 'bpanswick8@feedburner.com', 'China', 'Sanhe');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Blinni', '2005-08-01', 'Genderqueer', 'bmcshea9@i2i.jp', 'Czech Republic', 'Buchlovice');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Alisa', '2008-04-07', 'Female', 'ahammersleya@delicious.com', 'Poland', 'Lubień Kujawski');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Abigael', '2004-09-16', 'Female', 'adubockb@arstechnica.com', 'United States', 'Long Beach');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Aldon', '2007-04-28', 'Male', 'apavlikc@unicef.org', 'Syria', 'Sahnaiya');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Anita', '2007-12-04', 'Female', 'amaesd@uol.com.br', 'South Africa', 'Mtubatuba');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Averyl', '2004-07-14', 'Female', 'afouldse@google.es', 'Russia', 'Navashino');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Corliss', '2005-04-11', 'Polygender', 'ceglintonf@so-net.ne.jp', 'Sweden', 'Vindeln');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Gertruda', '2004-11-15', 'Bigender', 'gparmleyg@dyndns.org', 'Philippines', 'Guinticgan');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Bernadina', '2007-08-17', 'Genderfluid', 'bglashbyh@aol.com', 'Indonesia', 'Banjar Sandinggianyar');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Brittney', '2006-01-10', 'Female', 'blowdhami@tinypic.com', 'China', 'Beixiang');
--insert into Customers (Name, Birthdate, Gender, Email, Country, City) values ('Jonis', '2007-01-24', 'Female', 'jdalzielj@storify.com', 'Poland', 'Ochota');


--insert into Promotions (Name, Country, StartDate, EndDate) values ('ut massa', 'Indonesia', '2020-10-02', '2023-02-03');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('pretium', 'Indonesia', '2020-11-05', '2021-12-31');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('mattis', 'Philippines', '2020-12-25', '2023-05-24');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('dui vel sem', 'Portugal', '2021-03-19', '2021-09-04');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('ante', 'Ecuador', '2020-12-11', '2022-02-19');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('in magna', 'Mali', '2020-08-22', '2021-09-30');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('neque duis bibendum', 'Serbia', '2021-04-06', '2021-07-18');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('neque', 'Portugal', '2021-03-17', '2022-05-23');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('aliquam convallis', 'China', '2020-06-27', '2021-12-16');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('morbi a', 'Brazil', '2020-07-23', '2022-08-22');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('condimentum id', 'Indonesia', '2021-05-04', '2021-11-16');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('elit ac nulla', 'Serbia', '2020-11-14', '2021-12-31');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('erat', 'Czech Republic', '2021-05-13', '2022-01-04');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('diam erat', 'China', '2020-06-07', '2021-10-28');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('vivamus vestibulum sagittis', 'Portugal', '2020-09-10', '2022-06-22');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('lobortis convallis tortor', 'Russia', '2021-04-01', '2022-10-26');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('donec diam', 'Malawi', '2021-04-03', '2022-08-04');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('magnis dis parturient', 'Philippines', '2021-02-20', '2022-07-14');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('tempus vivamus in', 'Indonesia', '2020-06-07', '2021-10-09');
--insert into Promotions (Name, Country, StartDate, EndDate) values ('tincidunt lacus at', 'Serbia', '2021-03-21', '2023-06-04');

--insert into Interests (Name) values ('risus');
--insert into Interests (Name) values ('hac');
--insert into Interests (Name) values ('orci');
--insert into Interests (Name) values ('aliquet');
--insert into Interests (Name) values ('bibendum');
--insert into Interests (Name) values ('ut');
--insert into Interests (Name) values ('massa');
--insert into Interests (Name) values ('placerat');
--insert into Interests (Name) values ('ut');
--insert into Interests (Name) values ('lorem');
--insert into Interests (Name) values ('lacinia');
--insert into Interests (Name) values ('ultrices');
--insert into Interests (Name) values ('risus');
--insert into Interests (Name) values ('velit');
--insert into Interests (Name) values ('enim');
--insert into Interests (Name) values ('dapibus');
--insert into Interests (Name) values ('nisl');
--insert into Interests (Name) values ('ante');
--insert into Interests (Name) values ('in');
--insert into Interests (Name) values ('cras');

--insert into CustomerInterests (CustomerId, InterestId) values (6, 11);
--insert into CustomerInterests (CustomerId, InterestId) values (20, 4);
--insert into CustomerInterests (CustomerId, InterestId) values (6, 3);
--insert into CustomerInterests (CustomerId, InterestId) values (8, 2);
--insert into CustomerInterests (CustomerId, InterestId) values (7, 20);
--insert into CustomerInterests (CustomerId, InterestId) values (4, 3);
--insert into CustomerInterests (CustomerId, InterestId) values (13, 12);
--insert into CustomerInterests (CustomerId, InterestId) values (8, 12);
--insert into CustomerInterests (CustomerId, InterestId) values (7, 13);
--insert into CustomerInterests (CustomerId, InterestId) values (1, 13);
--insert into CustomerInterests (CustomerId, InterestId) values (9, 12);
--insert into CustomerInterests (CustomerId, InterestId) values (3, 19);
--insert into CustomerInterests (CustomerId, InterestId) values (9, 10);
--insert into CustomerInterests (CustomerId, InterestId) values (8, 7);
--insert into CustomerInterests (CustomerId, InterestId) values (18, 9);
--insert into CustomerInterests (CustomerId, InterestId) values (3, 20);
--insert into CustomerInterests (CustomerId, InterestId) values (14, 13);
--insert into CustomerInterests (CustomerId, InterestId) values (19, 20);
--insert into CustomerInterests (CustomerId, InterestId) values (15, 16);
--insert into CustomerInterests (CustomerId, InterestId) values (9, 17);
--insert into CustomerInterests (CustomerId, InterestId) values (4, 4);

--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (4, 3, 'Trueblue - Blueberry Cranberry');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (7, 5, 'Veal - Kidney');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (12, 6, 'Quail Eggs - Canned');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (5, 3, 'Juice - Grape, White');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (10, 1, 'Ham - Procutinni');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (20, 11, 'Capon - Breast, Double, Wing On');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (13, 6, 'Yogurt - Cherry, 175 Gr');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (8, 10, 'Beef - Striploin Aa');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (6, 6, 'Garbage Bags - Clear');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (11, 12, 'Tea - Darjeeling, Azzura');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (6, 4, 'Dried Figs');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (16, 7, 'Sobe - Green Tea');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (19, 15, 'Ginger - Ground');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (20, 20, 'Ice Cream Bar - Rolo Cone');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (13, 2, 'Cognac - Courvaisier');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (1, 3, 'Appetizer - Assorted Box');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (10, 11, 'Vermouth - Sweet, Cinzano');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (14, 11, 'Longos - Chicken Caeser Salad');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (18, 17, 'Cheese Cloth No 100');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (13, 15, 'Muffin - Zero Transfat');
--insert into PromotionProducts (PromotionId, InterestId, ProductName) values (21, 15, 'Muffin - Zero Transfat');


--create view CountryAndCountCity
--as
--SELECT Country, COUNT(City) AS Count
--FROM     dbo.Customers
--GROUP BY Country

--create view MaleAndInterests
--as
--select Interests.Name
--from CustomerInterests
--join Interests on Interests.Id = CustomerInterests.InterestId
--join Customers on Customers.ID = CustomerInterests.CustomerId
--where Gender = 'Male'

--create view FemaleAndInterests
--as
--select Interests.Name
--from CustomerInterests
--join Interests on Interests.Id = CustomerInterests.InterestId
--join Customers on Customers.ID = CustomerInterests.CustomerId
--where Gender = 'Female'







